import pygame

def key_down(event):
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_s:
            game.stop()
        
game.register_event_handler(key_down)