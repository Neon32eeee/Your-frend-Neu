def add_cheat_mod():
    # Состояние чита
    cheat_active = [False]  # Используем список для изменяемости
    cheat_mode = [None]     # Режим: None, 'num_hit', 'words', 'win_on', 'horror_mode', 'dialogue_text', 'user_name'
    input_text = ['']       # Текущий ввод пользователя
    error_message = ['']    # Сообщение об ошибке или успехе

    # Функция обработки событий
    def handle_cheat_event(event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                cheat_active[0] = not cheat_active[0]  # Вкл/выкл читов
                if not cheat_active[0]:
                    cheat_mode[0] = None
                    input_text[0] = ''
                    error_message[0] = ''
            elif cheat_active[0]:
                if event.key == pygame.K_1:
                    cheat_mode[0] = 'num_hit'  # Режим изменения num_hit
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_2:
                    cheat_mode[0] = 'words'    # Режим изменения слов
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_3:
                    cheat_mode[0] = 'win_on'   # Режим изменения win_on
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_4:
                    cheat_mode[0] = 'horror_mode'  # Режим изменения horror_mode
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_5:
                    cheat_mode[0] = 'dialogue_text'  # Режим изменения dialogue.text
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_6:
                    cheat_mode[0] = 'user_name'  # Режим изменения us_name.user_name_text
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_RETURN:
                    if input_text[0]:
                        try:
                            if cheat_mode[0] == 'num_hit':
                                neu.num_hit = int(input_text[0])  # Установка num_hit
                            elif cheat_mode[0] == 'words':
                                neu.words = [input_text[0]]       # Установка диалога
                            elif cheat_mode[0] == 'win_on':
                                stove.win_on = input_text[0].lower() in ('true', '1', 'yes')
                            elif cheat_mode[0] == 'horror_mode':
                                neu.horror_mode = input_text[0].lower() in ('true', '1', 'yes')
                            elif cheat_mode[0] == 'dialogue_text':
                                dialogue.text = input_text[0]      # Установка текста диалога
                            elif cheat_mode[0] == 'user_name':
                                us_name.user_name_text = input_text[0]  # Установка имени
                            error_message[0] = 'Успешно применено!'
                        except ValueError:
                            error_message[0] = 'Ошибка: неверный формат ввода'
                        input_text[0] = ''
                elif event.key == pygame.K_BACKSPACE:
                    input_text[0] = input_text[0][:-1]
                else:
                    input_text[0] += event.unicode

    # Функция отрисовки интерфейса чита
    def draw_cheat_content():
        if cheat_active[0]:
            # Отрисовка инструкций
            instructions = [
                "Читы: C - вкл/выкл,",
                "1 - num_hit (число), 2 - words (текст), 3 - win_on (true/false),",
                "4 - horror_mode (true/false), 5 - dialogue.text (текст),",
                "6 - user_name (текст), Enter - применить"
            ]
            for i, line in enumerate(instructions):
                text = font.render(line, True, (255, 0, 0))
                screen.blit(text, (50, 50 + i * 30))
            # Отрисовка текущего ввода
            input_display = font.render(f"Ввод: {input_text[0]}", True, (255, 0, 0))
            screen.blit(input_display, (50, 170))
            # Отрисовка текущего режима
            mode_text = f"Режим: {cheat_mode[0] or 'выберите (1–6)'}" 
            mode_display = font.render(mode_text, True, (255, 0, 0))
            screen.blit(mode_display, (50, 200))
            # Отрисовка текущих значений
            status_lines = [
                f"num_hit: {neu.num_hit}",
                f"words: {neu.words}",
                f"win_on: {stove.win_on}",
                f"horror_mode: {neu.horror_mode}",
                f"dialogue.text: {dialogue.text}",
                f"user_name: {us_name.user_name_text}"
            ]
            for i, line in enumerate(status_lines):
                status = font.render(line, True, (255, 0, 0))
                screen.blit(status, (50, 230 + i * 30))
            # Отрисовка сообщения об ошибке/успехе
            if error_message[0]:
                error_display = font.render(error_message[0], True, (255, 0, 0))
                screen.blit(error_display, (50, 410))

    # Регистрация функций
    mod_draw_functions.append(draw_cheat_content)
    mod_event_handlers.append(handle_cheat_event)

# Выполняем мод
add_cheat_mod()