import pygame
import random
import time

# Глобальные переменные для состояния мода
neu_mood = "normal"  # normal, happy, sad, angry
mood_change_time = 0
mood_messages = {
    "normal": ["Привет!", "Как дела?", "Что нового?"],
    "happy": ["Я так рад!", "Ты лучший!", "Это прекрасно!"],
    "sad": ["Мне грустно...", "Почему так?", "Не хочу говорить..."],
    "angry": ["Отстань!", "Не трогай меня!", "Я зол!"]
}
mood_colors = {
    "normal": (200, 200, 255),
    "happy": (255, 255, 150),
    "sad": (150, 150, 255),
    "angry": (255, 150, 150)
}
special_effects = []

# Функция изменения настроения
def change_mood(new_mood):
    global neu_mood, mood_change_time
    neu_mood = new_mood
    mood_change_time = time.time()
    
    # Спецэффекты для настроения
    if new_mood == "happy":
        for _ in range(30):
            x = random.randint(neu.rect.left, neu.rect.right)
            y = random.randint(neu.rect.top, neu.rect.bottom)
            size = random.randint(5, 15)
            lifetime = random.uniform(1.0, 2.0)
            special_effects.append({
                "type": "star",
                "pos": [x, y],
                "size": size,
                "color": (random.randint(200, 255), random.randint(200, 255), 0),
                "created": time.time(),
                "lifetime": lifetime
            })
    
    elif new_mood == "sad":
        for _ in range(10):
            x = random.randint(neu.rect.left, neu.rect.right)
            y = random.randint(neu.rect.bottom, neu.rect.bottom + 100)
            speed = random.uniform(1.0, 3.0)
            size = random.randint(3, 8)
            special_effects.append({
                "type": "tear",
                "pos": [x, y],
                "speed": speed,
                "size": size,
                "color": (150, 150, 255),
                "created": time.time()
            })

# Функция обработки событий для мода
def mood_event_handler(event):
    global neu_mood
    
    if event.type == pygame.KEYDOWN:
        # Секретная клавиша для изменения настроения (M)
        if event.key == pygame.K_m:
            moods = list(mood_messages.keys())
            current_index = moods.index(neu_mood)
            new_index = (current_index + 1) % len(moods)
            change_mood(moods[new_index])
    
    # Реакция на действия игрока
    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        if neu.rect.collidepoint(event.pos):
            # Нежный клик - улучшает настроение
            if neu_mood != "angry":
                if random.random() > 0.7:
                    change_mood("happy")
            else:
                if random.random() > 0.9:
                    change_mood("normal")

# Функция отрисовки для мода
def mood_draw_function():
    global special_effects
    
    # Отображение текущего настроения
    mood_text = font.render(f"Настроение: {neu_mood}", True, mood_colors[neu_mood])
    screen.blit(mood_text, (50, 50))
    
    # Отрисовка спецэффектов
    current_time = time.time()
    new_effects = []
    
    for effect in special_effects:
        if current_time - effect["created"] < effect.get("lifetime", 3.0):
            if effect["type"] == "star":
                pygame.draw.circle(screen, effect["color"], 
                                 [int(effect["pos"][0]), int(effect["pos"][1])], 
                                 effect["size"])
                new_effects.append(effect)
            
            elif effect["type"] == "tear":
                pygame.draw.circle(screen, effect["color"], 
                                 [int(effect["pos"][0]), int(effect["pos"][1])], 
                                 effect["size"])
                effect["pos"][1] += effect["speed"]
                new_effects.append(effect)
    
    special_effects = new_effects

# Модификация диалогов в зависимости от настроения
def modified_dialogue():
    if dialogue.open_second:
        dialogue.text = random.choice(mood_messages[neu_mood])
    
    # Изменение реакции на удар в зависимости от настроения
    if dialogue.open_hit:
        if neu_mood == "happy":
            dialogue.text = "Ой! Но я все равно рад!"
        elif neu_mood == "sad":
            dialogue.text = "Зачем ты делаешь мне больно?"
        elif neu_mood == "angry":
            dialogue.text = "ЕЩЕ РАЗ ТРОНЕШЬ - УБЬЮ!"
            neu.num_hit += 2  # В гневе удары более эффективны

# Интеграция с основной игрой
def integrate_with_game():
    # Замена стандартных диалогов
    neu.words = mood_messages["normal"]
    neu.stop_words = [
        "Хватит!", "Прекрати!", "Больше так не делай!",
        "Зачем ты это делаешь?", "Я серьезно, перестань!"
    ]
    
    # Изменение реакции на кормление
    original_food = neu.food
    def new_food():
        original_food()
        if random.random() > 0.5 and neu_mood != "angry":
            change_mood("happy")
    neu.food = new_food
    
    # Изменение реакции на удар
    original_hit = neu.hit
    def new_hit():
        original_hit()
        if neu_mood == "normal":
            if random.random() > 0.6:
                change_mood("sad")
        elif neu_mood == "happy":
            change_mood("sad")
        elif neu_mood == "sad":
            if random.random() > 0.8:
                change_mood("angry")
    neu.hit = new_hit

# Инициализация мода
def init_mod():
    mod_draw_functions.append(mood_draw_function)
    mod_event_handlers.append(mood_event_handler)
    integrate_with_game()

# Автозапуск мода при загрузке
init_mod()