def add_emotion_mod():
    # Состояние мода
    mod_active = [False]          # Вкл/выкл меню мода
    emotion_mode = [None]         # Текущее настроение: None, 'happy', 'sad', 'angry'
    input_text = ['']             # Текущий ввод для читов
    emotion_count = [0]           # Счетчик смен настроения
    error_message = ['']          # Сообщение об ошибке/успехе
    animation_timer = [0]         # Таймер для мигающего текста

    # Настройки для настроений
    emotions = {
        'happy': {
            'words': ['Я так счастлив!', 'Жизнь прекрасна!', 'Улыбка до ушей!'],
            'stop_words': ['Эй, не порти мне настроение!', 'Давай без этого!', 'Я же весёлый!'],
            'effect': lambda: setattr(neu, 'num_hit', max(0, neu.num_hit - 1))  # Уменьшает удары
        },
        'sad': {
            'words': ['Мне грустно...', 'Зачем всё это?', 'Эх, печалька...'],
            'stop_words': ['Ты делаешь мне ещё хуже!', 'Оставь меня...', 'И так грустно!'],
            'effect': lambda: setattr(neu, 'num_hit', min(10, neu.num_hit + 1))  # Увеличивает удары
        },
        'angry': {
            'words': ['Я в ярости!', 'Не зли меня!', 'Грр, достали!'],
            'stop_words': ['Ты пожалеешь!', 'Я зол, прекрати!', 'Не беси меня!'],
            'effect': lambda: setattr(neu, 'horror_mode', True)  # Включает хоррор-режим
        }
    }

    # Функция обработки событий
    def handle_emotion_event(event):
        nonlocal emotions
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                mod_active[0] = not mod_active[0]  # Вкл/выкл мода
                if not mod_active[0]:
                    emotion_mode[0] = None
                    input_text[0] = ''
                    error_message[0] = ''
            elif mod_active[0]:
                if event.key == pygame.K_1:
                    emotion_mode[0] = 'happy'
                    emotion_count[0] += 1
                    neu.words = emotions['happy']['words']
                    neu.stop_words = emotions['happy']['stop_words']
                    emotions['happy']['effect']()
                    error_message[0] = 'Настроение: Весёлое!'
                elif event.key == pygame.K_2:
                    emotion_mode[0] = 'sad'
                    emotion_count[0] += 1
                    neu.words = emotions['sad']['words']
                    neu.stop_words = emotions['sad']['stop_words']
                    emotions['sad']['effect']()
                    error_message[0] = 'Настроение: Грустное!'
                elif event.key == pygame.K_3:
                    emotion_mode[0] = 'angry'
                    emotion_count[0] += 1
                    neu.words = emotions['angry']['words']
                    neu.stop_words = emotions['angry']['stop_words']
                    emotions['angry']['effect']()
                    error_message[0] = 'Настроение: Злое!'
                elif event.key == pygame.K_4:
                    emotion_mode[0] = 'cheat_num_hit'  # Режим чита для num_hit
                    input_text[0] = ''
                    error_message[0] = ''
                elif event.key == pygame.K_RETURN and emotion_mode[0] == 'cheat_num_hit':
                    if input_text[0]:
                        try:
                            neu.num_hit = int(input_text[0])
                            error_message[0] = 'Удары изменены!'
                        except ValueError:
                            error_message[0] = 'Ошибка: введите число'
                        input_text[0] = ''
                elif event.key == pygame.K_BACKSPACE:
                    input_text[0] = input_text[0][:-1]
                elif emotion_mode[0] == 'cheat_num_hit':
                    input_text[0] += event.unicode

    # Функция отрисовки интерфейса мода
    def draw_emotion_content():
        if mod_active[0]:
            # Обновление таймера для анимации
            animation_timer[0] = (animation_timer[0] + 1) % 60  # 1 секунда цикла при 60 FPS
            alpha = 255 if animation_timer[0] < 30 else 100  # Мигающий эффект
            # Отрисовка инструкций
            instructions = [
                "Мини-игра эмоций: E - вкл/выкл,",
                "1 - Весёлое, 2 - Грустное, 3 - Злое, 4 - Чит num_hit, Enter - применить"
            ]
            for i, line in enumerate(instructions):
                text = font.render(line, True, (255, 0, 0))
                screen.blit(text, (50, 50 + i * 30))
            # Отрисовка текущего настроения с анимацией
            mode_text = f"Настроение: {emotion_mode[0] or 'выберите (1–3)'}" 
            mode_display = font.render(mode_text, True, (255, 0, 0))
            mode_display.set_alpha(alpha)
            screen.blit(mode_display, (50, 110))
            # Отрисовка счетчика эмоций
            count_display = font.render(f"Смен настроения: {emotion_count[0]}", True, (255, 0, 0))
            screen.blit(count_display, (50, 140))
            # Отрисовка текущего ввода для чита
            if emotion_mode[0] == 'cheat_num_hit':
                input_display = font.render(f"Ввод num_hit: {input_text[0]}", True, (255, 0, 0))
                screen.blit(input_display, (50, 170))
            # Отрисовка текущих значений
            status_lines = [
                f"num_hit: {neu.num_hit}",
                f"words: {neu.words}",
                f"horror_mode: {neu.horror_mode}"
            ]
            for i, line in enumerate(status_lines):
                status = font.render(line, True, (255, 0, 0))
                screen.blit(status, (50, 200 + i * 30))
            # Отрисовка сообщения
            if error_message[0]:
                error_display = font.render(error_message[0], True, (255, 0, 0))
                screen.blit(error_display, (50, 290))

    # Регистрация функций
    mod_draw_functions.append(draw_emotion_content)
    mod_event_handlers.append(handle_emotion_event)

# Выполняем мод
add_emotion_mod()