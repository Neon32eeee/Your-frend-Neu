import pygame
import random
import time

class SpaceBattle:
    def __init__(self, screen, neu, dialogue, stove):
        self.screen = screen
        self.neu = neu
        self.dialogue = dialogue
        self.stove = stove
        self.active = False
        self.score = 0
        self.start_time = 0
        
        # Player (Neu as a spaceship)
        self.player_size = (100, 100)
        self.player_pos = [960, 900]
        self.player_speed = 7
        self.player_surface = pygame.Surface(self.player_size, pygame.SRCALPHA)
        pygame.draw.polygon(self.player_surface, (50, 150, 255), [(50, 10), (20, 90), (80, 90)])  # Triangle ship
        pygame.draw.circle(self.player_surface, (255, 255, 0), (50, 30), 10)  # Cockpit
        self.player_rect = self.player_surface.get_rect(center=self.player_pos)
        
        # Space background with stars
        self.background = pygame.Surface((1920, 1080))
        self.background.fill((0, 0, 20))
        for _ in range(150):
            x, y = random.randint(0, 1920), random.randint(0, 1080)
            pygame.draw.circle(self.background, (255, 255, 255), (x, y), random.randint(1, 4))
        
        # Enemies
        self.enemies = []
        self.enemy_spawn_timer = 0
        self.enemy_spawn_interval = 1.5
        self.enemy_speed = 3
        self.wave = 1
        self.enemy_surface = pygame.Surface((60, 60), pygame.SRCALPHA)
        pygame.draw.rect(self.enemy_surface, (255, 50, 50), (10, 10, 40, 40))  # Square enemy with border
        pygame.draw.rect(self.enemy_surface, (255, 255, 255), (10, 10, 40, 40), 2)
        
        # Lasers
        self.lasers = []
        self.laser_speed = 12
        self.laser_cooldown = 0.25
        self.last_shot = 0
        self.laser_surface = pygame.Surface((10, 20), pygame.SRCALPHA)
        pygame.draw.rect(self.laser_surface, (255, 255, 0), (0, 0, 10, 20))  # Yellow laser
        self.laser_trail = pygame.Surface((10, 10), pygame.SRCALPHA)
        pygame.draw.circle(self.laser_trail, (255, 255, 0, 128), (5, 5), 5)  # Trail effect
        
        # Bonuses (hearts)
        self.bonuses = []
        self.bonus_spawn_timer = 0
        self.bonus_spawn_interval = 5
        self.bonus_surface = pygame.Surface((40, 40), pygame.SRCALPHA)
        pygame.draw.polygon(self.bonus_surface, (255, 200, 200), [(20, 10), (10, 30), (20, 40), (30, 30)])  # Heart shape
        
        # Explosion animation
        self.explosion_frames = [
            pygame.Surface((60, 60), pygame.SRCALPHA),
            pygame.Surface((80, 80), pygame.SRCALPHA),
            pygame.Surface((100, 100), pygame.SRCALPHA)
        ]
        pygame.draw.circle(self.explosion_frames[0], (255, 100, 0, 128), (30, 30), 20)
        pygame.draw.circle(self.explosion_frames[1], (255, 150, 0, 100), (40, 40), 30)
        pygame.draw.circle(self.explosion_frames[2], (255, 200, 0, 80), (50, 50), 40)
        self.explosions = []  # Store active explosions with frame and position
        
        # Score display
        self.font = pygame.font.Font(None, 36)
        self.score_text = self.font.render(f"Счёт: {self.score}", True, (255, 255, 255))
        
    def spawn_enemy(self):
        enemy_x = random.randint(0, 1920 - 60)
        enemy = {
            'surface': self.enemy_surface,
            'rect': self.enemy_surface.get_rect(topleft=(enemy_x, -60)),
            'speed': self.enemy_speed
        }
        self.enemies.append(enemy)

    def spawn_bonus(self):
        bonus_x = random.randint(0, 1920 - 40)
        bonus = {
            'surface': self.bonus_surface,
            'rect': self.bonus_surface.get_rect(topleft=(bonus_x, -40))
        }
        self.bonuses.append(bonus)

    def update(self):
        if not self.active:
            return

        # Player movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.player_rect.left > 0:
            self.player_rect.x -= self.player_speed
        if keys[pygame.K_RIGHT] and self.player_rect.right < 1920:
            self.player_rect.x += self.player_speed
        if keys[pygame.K_UP] and self.player_rect.top > 0:
            self.player_rect.y -= self.player_speed
        if keys[pygame.K_DOWN] and self.player_rect.bottom < 1080:
            self.player_rect.y += self.player_speed

        # Spawn enemies
        if time.time() - self.enemy_spawn_timer > self.enemy_spawn_interval:
            self.spawn_enemy()
            self.enemy_spawn_timer = time.time()
            if len(self.enemies) % 5 == 0 and len(self.enemies) > 0:
                self.wave += 1
                self.enemy_speed += 0.5
                self.enemy_spawn_interval = max(0.5, self.enemy_spawn_interval - 0.1)

        # Spawn bonuses
        if time.time() - self.bonus_spawn_timer > self.bonus_spawn_interval:
            self.spawn_bonus()
            self.bonus_spawn_timer = time.time()

        # Update lasers
        for laser in self.lasers[:]:
            laser['rect'].y -= self.laser_speed
            if laser['rect'].bottom < 0:
                self.lasers.remove(laser)

        # Update enemies
        for enemy in self.enemies[:]:
            enemy['rect'].y += enemy['speed']
            if enemy['rect'].top > 1080:
                self.enemies.remove(enemy)
            if enemy['rect'].colliderect(self.player_rect):
                self.active = False
                self.dialogue.text = "Корабль Нея уничтожен!"
                self.dialogue.open_second = True
                self.dialogue.start_time = time.time()
                self.explosions.append({'frame': 0, 'pos': self.player_rect.topleft, 'time': time.time()})

        # Update bonuses
        for bonus in self.bonuses[:]:
            bonus['rect'].y += 2
            if bonus['rect'].top > 1080:
                self.bonuses.remove(bonus)
            if bonus['rect'].colliderect(self.player_rect):
                self.bonuses.remove(bonus)
                self.neu.food()
                self.score += 50
                self.dialogue.text = "Сердечко поймано!"
                self.dialogue.open_second = True
                self.dialogue.start_time = time.time()

        # Update laser-enemy collisions
        for laser in self.lasers[:]:
            for enemy in self.enemies[:]:
                if laser['rect'].colliderect(enemy['rect']):
                    self.lasers.remove(laser)
                    self.enemies.remove(enemy)
                    self.score += 100
                    self.explosions.append({'frame': 0, 'pos': enemy['rect'].topleft, 'time': time.time()})
                    break

        # Update explosions
        for explosion in self.explosions[:]:
            if time.time() - explosion['time'] > 0.3:
                self.explosions.remove(explosion)
            else:
                explosion['frame'] = min(2, int((time.time() - explosion['time']) / 0.1))

        # Update score
        self.score_text = self.font.render(f"Счёт: {self.score}", True, (255, 255, 255))

    def draw(self):
        if not self.active:
            return
        self.screen.blit(self.background, (0, 0))
        self.screen.blit(self.player_surface, self.player_rect)
        for enemy in self.enemies:
            self.screen.blit(enemy['surface'], enemy['rect'])
        for laser in self.lasers:
            self.screen.blit(self.laser_surface, laser['rect'])
            self.screen.blit(self.laser_trail, (laser['rect'].x, laser['rect'].y + 20))  # Trail effect
        for bonus in self.bonuses:
            self.screen.blit(bonus['surface'], bonus['rect'])
        for explosion in self.explosions:
            self.screen.blit(self.explosion_frames[explosion['frame']], explosion['pos'])
        self.screen.blit(self.score_text, (50, 50))

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_5 and not self.dialogue.start and not self.stove.win_on and not self.neu.horror_mode:
                self.active = not self.active
                if self.active:
                    self.dialogue.text = "В бой, Ней!"
                    self.dialogue.open_second = True
                    self.dialogue.start_time = time.time()
                    self.player_rect.center = [960, 900]
                    self.enemies = []
                    self.lasers = []
                    self.bonuses = []
                    self.score = 0
                    self.wave = 1
                    self.enemy_speed = 3
                    self.enemy_spawn_interval = 1.5
            elif event.key == pygame.K_SPACE and self.active and time.time() - self.last_shot > self.laser_cooldown:
                laser_rect = self.laser_surface.get_rect(midbottom=self.player_rect.midtop)
                self.lasers.append({'surface': self.laser_surface, 'rect': laser_rect})
                self.last_shot = time.time()

# Initialize the space battle
space_battle = SpaceBattle(screen, neu, dialogue, stove)

# Add draw function
def draw_space_battle():
    space_battle.update()
    space_battle.draw()

# Add event handler
def handle_space_battle_event(event):
    space_battle.handle_event(event)

# Register the mod
mod_draw_functions.append(draw_space_battle)
mod_event_handlers.append(handle_space_battle_event)