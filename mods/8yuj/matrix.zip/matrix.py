# -*- coding: utf-8 -*-
def add_matrix_mod():
    # Состояние мода
    mod_active = [False]          # Вкл/выкл меню
    hack_mode = [None]            # Режим: None, миссии, 'cheat', 'cyber_chaos'
    input_text = ['']             # Текущий ввод для читов
    code_bytes = [0]              # Счетчик байтов кода
    error_message = ['']          # Сообщение об ошибке/успехе
    animation_timer = [0]         # Таймер для анимации
    cheat_variable = [None]       # Переменная для чита
    hack_count = [0]              # Счетчик взломов
    matrix_particles = []         # Частицы для цифрового дождя
    glitch_particles = []         # Частицы для глюков
    flash_particles = []          # Частицы для вспышек
    achievements = []             # Достижения
    animation_speed = [1.0]       # Множитель скорости анимации
    impulse_timer = [0]           # Таймер для кибер-импульса
    particle_update_counter = [0] # Счетчик для оптимизации частиц

    # Миссии
    missions = {
        'hack_hits': {
            'description': 'Взломай удары (num_hit -> 0)!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 2), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: setattr(neu, 'num_hit', 0),
            'dialogues': ['Код ударов взломан!', 'Я чист, бро!', 'Хиты обнулены!'],
            'stop_dialogues': ['Эй, не бей хакера!', 'Я в Матрице, чувак!', 'Код защищает!']
        },
        'hack_dialogue': {
            'description': 'Ускори анимацию интерфейса!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 1), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: animation_speed.__setitem__(0, 1.5),
            'dialogues': ['Диалоги переписаны!', 'Я говорю кодом!', 'Матрица рулит!'],
            'stop_dialogues': ['Не мешай моему коду!', 'Я занят взломом!', 'Код в процессе!']
        },
        'hack_reality': {
            'description': 'Отключи хоррор и печь!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 3), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: (setattr(neu, 'horror_mode', False), setattr(stove, 'win_on', False), animation_speed.__setitem__(0, 0.5)),
            'dialogues': ['Реальность взломана!', 'Хоррор отключен!', 'Печь не работает!'],
            'stop_dialogues': ['Не бей, я вне Матрицы!', 'Реальность под контролем!', 'Код спасает!']
        },
        'hack_time': {
            'description': 'Взломай таймеры игры!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 2), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: (setattr(neu, 'horror_time_start', time.time()), setattr(dialogue, 'start_time', time.time())),
            'dialogues': ['Время под контролем!', 'Таймеры взломаны!', 'Код времени мой!'],
            'stop_dialogues': ['Не ломай мой таймер!', 'Время хакнуто!', 'Код времени сбоит!']
        },
        'hack_name': {
            'description': 'Перепиши имя игрока!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 1), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: setattr(us_name, 'user_name_text', 'CYBER_' + us_name.user_name_text[:10]),
            'dialogues': ['Имя хакнуто!', 'Я новый кибер-игрок!', 'Код имени изменен!'],
            'stop_dialogues': ['Мое имя под защитой!', 'Не трогай мой код!', 'Имя в Матрице!']
        },
        'reset_reality': {
            'description': 'Сбрось реальность до начальной!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 5), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: (
                setattr(neu, 'num_hit', 0),
                setattr(neu, 'horror_mode', False),
                setattr(neu, 'stove_mode', False),
                setattr(neu, 'words', ['Сколько тебе лет?', 'Как дела?', 'Какой твой любимый цвет?']),
                setattr(neu, 'stop_words', ['Хватит!', 'Прекрати!', 'Зачем ты это делаешь?']),
                setattr(stove, 'win_on', False),
                setattr(us_name, 'user_name_text', ''),
                setattr(dialogue, 'text', ''),
                setattr(neu, 'pozition', (500, 350))
            ),
            'dialogues': ['Реальность сброшена!', 'Код очищен!', 'Назад к началу!'],
            'stop_dialogues': ['Сброс? Серьезно?', 'Код перезагружен!', 'Матрица очищена!']
        },
        'cyber_chaos': {
            'description': 'Кибер-хаос: Полный беспорядок!',
            'action': lambda: (code_bytes.__setitem__(0, code_bytes[0] + 5), impulse_timer.__setitem__(0, 30)),
            'effect': lambda: (
                setattr(neu, 'pozition', (random.randint(50, 1500), random.randint(50, 800))),
                setattr(neu, 'words', ['ХАОС!', 'КОД СБОИТ!', 'МАТРИЦА ВЗОРВАНА!']),
                setattr(neu, 'horror_mode', random.choice([True, False])),
                setattr(dialogue, 'text', random.choice(['ГЛЮК!', 'ВЗЛОМ!', 'ХАОС!'])),
                animation_speed.__setitem__(0, random.uniform(0.5, 2.0))
            ),
            'dialogues': ['Я в хаосе!', 'Код ломается!', 'Матрица сходит с ума!'],
            'stop_dialogues': ['Хаос, не бей!', 'Я в цифровом аду!', 'Код развалился!']
        }
    }

    # Инициализация частиц
    def init_particles():
        matrix_particles.clear()
        glitch_particles.clear()
        flash_particles.clear()
        for _ in range(100):  # 100 частиц цифрового дождя
            matrix_particles.append({
                'x': random.randint(50, 1870),
                'y': random.randint(-3000, 0),
                'speed': random.uniform(5, 30) * animation_speed[0],
                'drift': random.uniform(-0.7, 0.7),
                'char': random.choice('01@#$%*+-=/|><'),
                'color': random.choice([(0, 255, 0), (0, 200, 255), (255, 255, 255)]),
                'alpha': random.randint(80, 255)
            })
        for _ in range(30):  # 30 глюк-частиц
            glitch_particles.append({
                'x': random.choice([random.randint(0, 50), random.randint(1870, 1920)]),
                'y': random.choice([random.randint(0, 50), random.randint(1030, 1080)]),
                'char': random.choice('!@#$%^&*?'),
                'alpha': random.randint(50, 150),
                'dx': random.uniform(-1, 1),
                'dy': random.uniform(-1, 1)
            })
        for _ in range(10):  # 10 вспышек для хаоса
            flash_particles.append({
                'x': random.randint(50, 1870),
                'y': random.randint(50, 1030),
                'char': random.choice('X*#+'),
                'alpha': random.randint(50, 200),
                'size': random.randint(20, 50)
            })

    # Проверка достижений
    def check_achievements():
        if hack_count[0] >= 10 and 'Мастер взлома' not in achievements:
            achievements.append('Мастер взлома')
            error_message[0] = 'Достижение: Мастер взлома!'
            impulse_timer[0] = 30
        if code_bytes[0] >= 20 and 'Кибер-гуру' not in achievements:
            achievements.append('Кибер-гуру')
            error_message[0] = 'Достижение: Кибер-гуру!'
            impulse_timer[0] = 30

    # Функция обработки событий
    def handle_matrix_event(event):
        nonlocal missions
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_h:
                mod_active[0] = not mod_active[0]
                if mod_active[0]:
                    init_particles()
                else:
                    hack_mode[0] = None
                    input_text[0] = ''
                    error_message[0] = ''
                    cheat_variable[0] = None
                    animation_speed[0] = 1.0
                    impulse_timer[0] = 0
            elif mod_active[0]:
                if event.key == pygame.K_q:  # Перезагрузка частиц
                    init_particles()
                    error_message[0] = 'Частицы перезагружены!'
                elif event.key == pygame.K_1:
                    hack_mode[0] = 'hack_hits'
                    hack_count[0] += 1
                    missions['hack_hits']['action']()
                    missions['hack_hits']['effect']()
                    error_message[0] = 'Миссия: Взлом ударов!'
                    check_achievements()
                    if code_bytes[0] >= 20:
                        hack_mode[0] = 'cyber_chaos'
                        neu.words = missions['cyber_chaos']['dialogues']
                        neu.stop_words = missions['cyber_chaos']['stop_dialogues']
                        missions['cyber_chaos']['action']()
                        missions['cyber_chaos']['effect']()
                        error_message[0] = 'Кибер-хаос активирован!'
                elif event.key == pygame.K_2:
                    hack_mode[0] = 'hack_dialogue'
                    hack_count[0] += 1
                    missions['hack_dialogue']['action']()
                    missions['hack_dialogue']['effect']()
                    error_message[0] = 'Миссия: Анимация ускорена!'
                    check_achievements()
                elif event.key == pygame.K_3:
                    hack_mode[0] = 'hack_reality'
                    hack_count[0] += 1
                    missions['hack_reality']['action']()
                    missions['hack_reality']['effect']()
                    error_message[0] = 'Миссия: Взлом реальности!'
                    check_achievements()
                elif event.key == pygame.K_4:
                    hack_mode[0] = 'hack_time'
                    hack_count[0] += 1
                    neu.words = missions['hack_time']['dialogues']
                    neu.stop_words = missions['hack_time']['stop_dialogues']
                    missions['hack_time']['action']()
                    missions['hack_time']['effect']()
                    error_message[0] = 'Миссия: Взлом времени!'
                    check_achievements()
                elif event.key == pygame.K_5:
                    hack_mode[0] = 'hack_name'
                    hack_count[0] += 1
                    neu.words = missions['hack_name']['dialogues']
                    neu.stop_words = missions['hack_name']['stop_dialogues']
                    missions['hack_name']['action']()
                    missions['hack_name']['effect']()
                    error_message[0] = 'Миссия: Взлом имени!'
                    check_achievements()
                elif event.key == pygame.K_6:
                    hack_mode[0] = 'reset_reality'
                    hack_count[0] += 1
                    neu.words = missions['reset_reality']['dialogues']
                    neu.stop_words = missions['reset_reality']['stop_dialogues']
                    missions['reset_reality']['action']()
                    missions['reset_reality']['effect']()
                    error_message[0] = 'Миссия: Сброс реальности!'
                    check_achievements()
                elif event.key == pygame.K_7:
                    hack_mode[0] = 'cheat'
                    cheat_variable[0] = 'num_hit'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод num_hit'
                elif event.key == pygame.K_8 and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'words'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод words'
                elif event.key == pygame.K_9 and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'horror_mode'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод horror_mode (true/false)'
                elif event.key == pygame.K_0 and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'win_on'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод win_on (true/false)'
                elif event.key == pygame.K_i and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'user_name'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод user_name'
                elif event.key == pygame.K_o and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'pozition'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод pozition (x,y)'
                elif event.key == pygame.K_p and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'dialogue_text'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод dialogue.text'
                elif event.key == pygame.K_l and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'dialogue_start'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод dialogue.start (true/false)'
                elif event.key == pygame.K_k and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'neu_size'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод neu.size (width,height)'
                elif event.key == pygame.K_j and hack_mode[0] == 'cheat':
                    cheat_variable[0] = 'text_pozition'
                    input_text[0] = ''
                    error_message[0] = 'Чит: Ввод dialogue.text_pozition (x,y)'
                elif event.key == pygame.K_RETURN and hack_mode[0] == 'cheat' and input_text[0]:
                    try:
                        if cheat_variable[0] == 'num_hit':
                            neu.num_hit = int(input_text[0])
                            error_message[0] = 'Удары взломаны!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'words':
                            neu.words = [input_text[0]]
                            error_message[0] = 'Диалоги взломаны!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'horror_mode':
                            neu.horror_mode = input_text[0].lower() in ('true', '1', 'yes')
                            error_message[0] = 'Хоррор-режим взломан!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'win_on':
                            stove.win_on = input_text[0].lower() in ('true', '1', 'yes')
                            error_message[0] = 'Режим печи взломан!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'user_name':
                            us_name.user_name_text = input_text[0]
                            error_message[0] = 'Имя взломано!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'pozition':
                            x, y = map(int, input_text[0].split(','))
                            neu.pozition = (x, y)
                            error_message[0] = 'Позиция взломана!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'dialogue_text':
                            dialogue.text = input_text[0]
                            error_message[0] = 'Текст диалога взломан!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'dialogue_start':
                            dialogue.start = input_text[0].lower() in ('true', '1', 'yes')
                            error_message[0] = 'Стартовый экран взломан!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'neu_size':
                            w, h = map(int, input_text[0].split(','))
                            neu.size = (w, h)
                            neu.image = pygame.transform.scale(neu.image, neu.size)
                            error_message[0] = 'Размер Neu взломан!'
                            impulse_timer[0] = 30
                        elif cheat_variable[0] == 'text_pozition':
                            x, y = map(int, input_text[0].split(','))
                            dialogue.text_pozition = (x, y)
                            error_message[0] = 'Позиция текста взломана!'
                            impulse_timer[0] = 30
                        hack_count[0] += 1
                        code_bytes[0] += 1
                        check_achievements()
                        input_text[0] = ''
                    except ValueError:
                        error_message[0] = 'Ошибка: неверный формат (число, true/false или x,y)'
                        input_text[0] = ''
                elif event.key == pygame.K_BACKSPACE:
                    input_text[0] = input_text[0][:-1]
                elif hack_mode[0] == 'cheat':
                    input_text[0] += event.unicode

    # Функция отрисовки интерфейса
    def draw_matrix_content():
        if mod_active[0]:
            # Обновление частиц (каждые 2 кадра для оптимизации)
            animation_timer[0] = (animation_timer[0] + 1) % 60
            impulse_timer[0] = max(0, impulse_timer[0] - 1)
            particle_update_counter[0] = (particle_update_counter[0] + 1) % 2
            alpha = 255 if animation_timer[0] < 30 else 100
            particle_color = (255, 0, 0) if impulse_timer[0] > 0 else None
            if particle_update_counter[0] == 0:
                for particle in matrix_particles:
                    particle['y'] += particle['speed'] * animation_speed[0]
                    particle['x'] += particle['drift']
                    if particle['y'] > 1080 or particle['x'] < 0 or particle['x'] > 1920:
                        particle['y'] = random.randint(-3000, 0)
                        particle['x'] = random.randint(50, 1870)
                        particle['char'] = random.choice('01@#$%*+-=/|><')
                        particle['color'] = random.choice([(0, 255, 0), (0, 200, 255), (255, 255, 255)])
                        particle['alpha'] = random.randint(80, 255)
                for particle in glitch_particles:
                    particle['x'] += particle['dx']
                    particle['y'] += particle['dy']
                    particle['alpha'] = random.randint(50, 150) if hack_mode[0] == 'cyber_chaos' else particle['alpha']
                    if particle['x'] < 0 or particle['x'] > 1920 or particle['y'] < 0 or particle['y'] > 1080:
                        particle['x'] = random.choice([random.randint(0, 50), random.randint(1870, 1920)])
                        particle['y'] = random.choice([random.randint(0, 50), random.randint(1030, 1080)])
                        particle['dx'] = random.uniform(-1, 1)
                        particle['dy'] = random.uniform(-1, 1)
            for particle in matrix_particles:
                char_text = font.render(particle['char'], True, particle_color or particle['color'])
                char_text.set_alpha(particle['alpha'])
                screen.blit(char_text, (particle['x'], particle['y']))
            for particle in glitch_particles:
                glitch_text = font.render(particle['char'], True, particle_color or (255, 0, 0))
                glitch_text.set_alpha(particle['alpha'])
                screen.blit(glitch_text, (particle['x'], particle['y']))
            if hack_mode[0] == 'cyber_chaos':
                for particle in flash_particles:
                    particle['alpha'] = random.randint(50, 200)
                    flash_text = pygame.font.Font(None, particle['size']).render(particle['char'], True, particle_color or (255, 0, 0))
                    flash_text.set_alpha(particle['alpha'])
                    screen.blit(flash_text, (particle['x'], particle['y']))

            # Отрисовка заголовка
            title = font.render("Neu: Хакерская Матрица", True, particle_color or (0, 255, 0))
            title.set_alpha(alpha)
            screen.blit(title, (50, 50))
            # Отрисовка инструкций
            instructions = [
                "H - вкл/выкл, Q - перезагрузить частицы, 1 - Удары, 2 - Анимация, 3 - Реальность",
                "4 - Время, 5 - Имя, 6 - Сброс, 7 - Читы (7:j,k,l,o,p - переменная, Enter)"
            ]
            for i, line in enumerate(instructions):
                text = font.render(line, True, particle_color or (0, 255, 0))
                screen.blit(text, (50, 80 + i * 30))
            # Отрисовка миссии
            mission_text = f"Миссия: {missions.get(hack_mode[0], {}).get('description', 'выберите (1–6)')}"
            mission_display = font.render(mission_text, True, particle_color or (0, 255, 0))
            mission_display.set_alpha(alpha)
            screen.blit(mission_display, (50, 140))
            # Отрисовка байтов, взломов и достижений
            bytes_display = font.render(f"Байты кода: {code_bytes[0]}", True, particle_color or (0, 255, 0))
            screen.blit(bytes_display, (50, 170))
            hacks_display = font.render(f"Взломов: {hack_count[0]}", True, particle_color or (0, 255, 0))
            screen.blit(hacks_display, (50, 200))
            ach_display = font.render(f"Достижения: {', '.join(achievements) or 'нет'}", True, particle_color or (0, 255, 0))
            screen.blit(ach_display, (50, 230))
            # Отрисовка ввода для чита
            if hack_mode[0] == 'cheat':
                cheat_display = font.render(f"Читы ({cheat_variable[0] or 'выберите 7–p'}): {input_text[0]}", True, particle_color or (0, 255, 0))
                screen.blit(cheat_display, (50, 260))
            # Отрисовка текущих значений
            status_lines = [
                f"num_hit: {neu.num_hit}",
                f"words: {neu.words}",
                f"horror_mode: {neu.horror_mode}",
                f"win_on: {stove.win_on}",
                f"user_name: {us_name.user_name_text}",
                f"pozition: {neu.pozition}",
                f"dialogue_text: {dialogue.text}",
                f"dialogue_start: {dialogue.start}",
                f"neu_size: {neu.size}",
                f"text_pozition: {dialogue.text_pozition}"
            ]
            for i, line in enumerate(status_lines):
                status = font.render(line, True, particle_color or (0, 255, 0))
                screen.blit(status, (50, 290 + i * 30))
            # Отрисовка сообщения
            if error_message[0]:
                error_display = font.render(error_message[0], True, particle_color or (0, 255, 0))
                screen.blit(error_display, (50, 590))

    # Регистрация функций
    mod_draw_functions.append(draw_matrix_content)
    mod_event_handlers.append(handle_matrix_event)

# Выполняем мод
add_matrix_mod()