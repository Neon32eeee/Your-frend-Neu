import pygame
import random
import time
import math

class SpaceBattle:
    def __init__(self, screen, neu, dialogue, stove):
        self.screen = screen
        self.neu = neu
        self.dialogue = dialogue
        self.stove = stove
        self.active = False
        self.score = 0
        self.ultimate_charge = 0
        self.start_time = 0
        
        # Player (Neu as a detailed spaceship)
        self.player_size = (120, 120)
        self.player_pos = [960, 900]
        self.player_speed = 8
        self.player_angle = 0
        self.player_surface = pygame.Surface(self.player_size, pygame.SRCALPHA)
        pygame.draw.polygon(self.player_surface, (50, 150, 255), [(60, 20), (20, 100), (100, 100)])  # Main body
        pygame.draw.polygon(self.player_surface, (100, 200, 255), [(40, 80), (20, 100), (40, 100)])  # Left wing
        pygame.draw.polygon(self.player_surface, (100, 200, 255), [(80, 80), (100, 100), (80, 100)])  # Right wing
        pygame.draw.circle(self.player_surface, (255, 255, 0), (60, 40), 15)  # Cockpit
        pygame.draw.rect(self.player_surface, (255, 100, 0), (50, 90, 20, 20))  # Thruster
        self.player_rect = self.player_surface.get_rect(center=self.player_pos)
        
        # Parallax background (using lists instead of tuples)
        self.background = pygame.Surface((1920, 1080))
        self.background.fill((0, 0, 20))
        self.stars = [[random.randint(0, 1920), random.randint(0, 1080), random.randint(1, 4), random.uniform(0.5, 2)] for _ in range(200)]
        
        # Enemies (UFO-like design)
        self.enemies = []
        self.enemy_spawn_timer = 0
        self.enemy_spawn_interval = 1.3
        self.enemy_speed = 3.5
        self.wave = 1
        self.enemy_surface = pygame.Surface((80, 80), pygame.SRCALPHA)
        pygame.draw.circle(self.enemy_surface, (255, 50, 50), (40, 40), 30)  # UFO body
        pygame.draw.circle(self.enemy_surface, (255, 255, 255), (40, 40), 30, 2)  # Border
        pygame.draw.circle(self.enemy_surface, (0, 255, 255), (40, 20), 10)  # Cockpit
        pygame.draw.rect(self.enemy_surface, (255, 50, 50), (30, 50, 20, 10))  # Base
        
        # Lasers
        self.lasers = []
        self.laser_speed = 15
        self.laser_cooldown = 0.2
        self.last_shot = 0
        self.laser_surface = pygame.Surface((12, 24), pygame.SRCALPHA)
        pygame.draw.rect(self.laser_surface, (255, 255, 0), (0, 0, 12, 24))
        pygame.draw.rect(self.laser_surface, (255, 255, 255), (0, 0, 12, 24), 1)
        self.laser_trail = pygame.Surface((12, 12), pygame.SRCALPHA)
        pygame.draw.circle(self.laser_trail, (255, 255, 0, 100), (6, 6), 6)
        
        # Bonuses (hearts)
        self.bonuses = []
        self.bonus_spawn_timer = 0
        self.bonus_spawn_interval = 4
        self.bonus_surface = pygame.Surface((50, 50), pygame.SRCALPHA)
        pygame.draw.polygon(self.bonus_surface, (255, 150, 150), [(25, 10), (10, 30), (25, 40), (40, 30)])
        pygame.draw.polygon(self.bonus_surface, (255, 200, 200), [(25, 15), (15, 30), (25, 35), (35, 30)])
        
        # Explosion animation
        self.explosion_frames = [
            pygame.Surface((80, 80), pygame.SRCALPHA),
            pygame.Surface((100, 100), pygame.SRCALPHA),
            pygame.Surface((120, 120), pygame.SRCALPHA),
            pygame.Surface((140, 140), pygame.SRCALPHA)
        ]
        pygame.draw.circle(self.explosion_frames[0], (255, 100, 0, 150), (40, 40), 30)
        pygame.draw.circle(self.explosion_frames[1], (255, 150, 0, 120), (50, 50), 40)
        pygame.draw.circle(self.explosion_frames[2], (255, 200, 0, 100), (60, 60), 50)
        pygame.draw.circle(self.explosion_frames[3], (255, 255, 0, 80), (70, 70), 60)
        self.explosions = []
        
        # Ultimate attack effect (pulsating)
        self.ultimate_frames = [
            pygame.Surface((1920, 1080), pygame.SRCALPHA),
            pygame.Surface((1920, 1080), pygame.SRCALPHA),
            pygame.Surface((1920, 1080), pygame.SRCALPHA)
        ]
        pygame.draw.circle(self.ultimate_frames[0], (255, 255, 255, 80), (960, 540), 300)
        pygame.draw.circle(self.ultimate_frames[1], (255, 255, 0, 100), (960, 540), 400)
        pygame.draw.circle(self.ultimate_frames[2], (255, 255, 255, 60), (960, 540), 500)
        self.ultimate_active = False
        self.ultimate_time = 0
        self.ultimate_frame = 0
        
        # UI
        self.font = pygame.font.Font(None, 36)
        self.score_text = self.font.render(f"Счёт: {self.score}", True, (255, 255, 255))
        self.ultimate_text = self.font.render(f"Ультимейтов: {self.ultimate_charge}/500", True, (255, 255, 255))

    def spawn_enemy(self):
        enemy_x = random.randint(0, 1920 - 80)
        enemy = {
            'surface': self.enemy_surface,
            'rect': self.enemy_surface.get_rect(topleft=(enemy_x, -80)),
            'speed': self.enemy_speed
        }
        self.enemies.append(enemy)

    def spawn_bonus(self):
        bonus_x = random.randint(0, 1920 - 50)
        bonus = {
            'surface': self.bonus_surface,
            'rect': self.bonus_surface.get_rect(topleft=(bonus_x, -50))
        }
        self.bonuses.append(bonus)

    def update(self):
        if not self.active:
            return

        # Parallax star movement (using lists)
        for star in self.stars:
            star[1] = (star[1] + star[3]) % 1080

        # Player movement and rotation
        keys = pygame.key.get_pressed()
        old_x, old_y = self.player_rect.center
        if keys[pygame.K_LEFT] and self.player_rect.left > 0:
            self.player_rect.x -= self.player_speed
            self.player_angle = min(self.player_angle + 5, 15)
        elif keys[pygame.K_RIGHT] and self.player_rect.right < 1920:
            self.player_rect.x += self.player_speed
            self.player_angle = max(self.player_angle - 5, -15)
        else:
            self.player_angle = self.player_angle * 0.9  # Smoothly return to center
        if keys[pygame.K_UP] and self.player_rect.top > 0:
            self.player_rect.y -= self.player_speed
        if keys[pygame.K_DOWN] and self.player_rect.bottom < 1080:
            self.player_rect.y += self.player_speed

        # Spawn enemies
        if time.time() - self.enemy_spawn_timer > self.enemy_spawn_interval:
            self.spawn_enemy()
            self.enemy_spawn_timer = time.time()
            if len(self.enemies) % 5 == 0 and len(self.enemies) > 0:
                self.wave += 1
                self.enemy_speed += 0.6
                self.enemy_spawn_interval = max(0.4, self.enemy_spawn_interval - 0.1)

        # Spawn bonuses
        if time.time() - self.bonus_spawn_timer > self.bonus_spawn_interval:
            self.spawn_bonus()
            self.bonus_spawn_timer = time.time()

        # Update lasers
        for laser in self.lasers[:]:
            laser['rect'].y -= self.laser_speed
            if laser['rect'].bottom < 0:
                self.lasers.remove(laser)

        # Update enemies
        for enemy in self.enemies[:]:
            enemy['rect'].y += enemy['speed']
            if enemy['rect'].top > 1080:
                self.enemies.remove(enemy)
            if enemy['rect'].colliderect(self.player_rect) and not self.ultimate_active:
                self.active = False
                self.dialogue.text = "Мой корабль взорвался!"
                self.dialogue.open_second = True
                self.dialogue.start_time = time.time()
                self.explosions.append({'frame': 0, 'pos': self.player_rect.topleft, 'time': time.time()})

        # Update bonuses
        for bonus in self.bonuses[:]:
            bonus['rect'].y += 2
            if bonus['rect'].top > 1080:
                self.bonuses.remove(bonus)
            if bonus['rect'].colliderect(self.player_rect):
                self.bonuses.remove(bonus)
                self.neu.food()
                self.score += 50
                self.ultimate_charge += 50
                self.dialogue.text = "Сердце для Нея!"
                self.dialogue.open_second = True
                self.dialogue.start_time = time.time()

        # Update laser-enemy collisions
        for laser in self.lasers[:]:
            for enemy in self.enemies[:]:
                if laser['rect'].colliderect(enemy['rect']):
                    self.lasers.remove(laser)
                    self.enemies.remove(enemy)
                    self.score += 100
                    self.ultimate_charge += 20
                    self.explosions.append({'frame': 0, 'pos': enemy['rect'].topleft, 'time': time.time()})
                    break

        # Update explosions
        for explosion in self.explosions[:]:
            if time.time() - explosion['time'] > 0.4:
                self.explosions.remove(explosion)
            else:
                explosion['frame'] = min(3, int((time.time() - explosion['time']) / 0.1))

        # Update ultimate
        if self.ultimate_active:
            self.ultimate_frame = (self.ultimate_frame + 1) % 3
            if time.time() - self.ultimate_time > 0.6:
                self.ultimate_active = False
                self.enemies.clear()
                self.ultimate_charge = 0

        # Update UI
        self.score_text = self.font.render(f"Счёт: {self.score}", True, (255, 255, 255))
        self.ultimate_text = self.font.render("Ультимейтов: Готов!", True, (255, 255, 0)) if self.ultimate_charge >= 500 else self.font.render(f"Ультимейтов: {self.ultimate_charge}/500", True, (255, 255, 255))

    def draw(self):
        if not self.active:
            return
        # Draw parallax background
        self.screen.blit(self.background, (0, 0))
        for x, y, size, _ in self.stars:
            pygame.draw.circle(self.screen, (255, 255, 255), (x, int(y)), size)
        
        # Draw ultimate effect
        if self.ultimate_active:
            self.screen.blit(self.ultimate_frames[self.ultimate_frame], (0, 0))
        
        # Draw rotated player
        rotated_player = pygame.transform.rotate(self.player_surface, self.player_angle)
        rotated_rect = rotated_player.get_rect(center=self.player_rect.center)
        self.screen.blit(rotated_player, rotated_rect)
        
        # Draw game objects
        for enemy in self.enemies:
            self.screen.blit(enemy['surface'], enemy['rect'])
        for laser in self.lasers:
            self.screen.blit(self.laser_surface, laser['rect'])
            self.screen.blit(self.laser_trail, (laser['rect'].x, laser['rect'].y + 24))
        for bonus in self.bonuses:
            self.screen.blit(bonus['surface'], bonus['rect'])
        for explosion in self.explosions:
            self.screen.blit(self.explosion_frames[explosion['frame']], explosion['pos'])
        
        # Draw UI
        self.screen.blit(self.score_text, (50, 50))
        self.screen.blit(self.ultimate_text, (50, 100))

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_5 and not self.dialogue.start and not self.stove.win_on and not self.neu.horror_mode:
                self.active = not self.active
                if self.active:
                    self.dialogue.text = "Ней в космосе!"
                    self.dialogue.open_second = True
                    self.dialogue.start_time = time.time()
                    self.player_rect.center = [960, 900]
                    self.player_angle = 0
                    self.enemies = []
                    self.lasers = []
                    self.bonuses = []
                    self.explosions = []
                    self.score = 0
                    self.ultimate_charge = 0
                    self.wave = 1
                    self.enemy_speed = 3.5
                    self.enemy_spawn_interval = 1.3
            elif event.key == pygame.K_SPACE and self.active and time.time() - self.last_shot > self.laser_cooldown:
                laser_rect = self.laser_surface.get_rect(midbottom=self.player_rect.midtop)
                self.lasers.append({'surface': self.laser_surface, 'rect': laser_rect})
                self.last_shot = time.time()
            elif event.key == pygame.K_q and self.active and self.ultimate_charge >= 500:
                self.ultimate_active = True
                self.ultimate_time = time.time()
                self.ultimate_frame = 0
                self.dialogue.text = "ГАЛАКТИЧЕСКИЙ ВЗРЫВ!"
                self.dialogue.open_second = True
                self.dialogue.start_time = time.time()
                self.score += len(self.enemies) * 100

# Initialize the space battle
space_battle = SpaceBattle(screen, neu, dialogue, stove)

# Add draw function
def draw_space_battle():
    space_battle.update()
    space_battle.draw()

# Add event handler
def handle_space_battle_event(event):
    space_battle.handle_event(event)

# Register the mod
mod_draw_functions.append(draw_space_battle)
mod_event_handlers.append(handle_space_battle_event)